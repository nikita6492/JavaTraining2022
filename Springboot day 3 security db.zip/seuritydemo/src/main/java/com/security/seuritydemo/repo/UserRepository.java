package com.security.seuritydemo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.security.seuritydemo.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {

	User findByUsername(String username);

}
