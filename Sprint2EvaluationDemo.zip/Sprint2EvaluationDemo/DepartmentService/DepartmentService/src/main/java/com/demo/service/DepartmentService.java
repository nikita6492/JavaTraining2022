package com.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.entity.Department;
import com.demo.repository.DepartmentRepository;

@Service
public class DepartmentService {
	
	@Autowired
	private DepartmentRepository departmentRepository;
	
	public Department addDepartment(Department department) {
		return departmentRepository.save(department);
	}
	
	public List<Department> getAllDepartments(){
		return departmentRepository.findAll();
	}
		
	
	public Department updateDepartment(Department department) {
		return departmentRepository.save(department);
	}
	
	public void deleteDepartment(Long departmentId) {
		departmentRepository.deleteById(departmentId);
	}

	public Department findByDepartmentById(Long departmentId) {
		return departmentRepository.findByDepartmentId(departmentId);
	}
}
