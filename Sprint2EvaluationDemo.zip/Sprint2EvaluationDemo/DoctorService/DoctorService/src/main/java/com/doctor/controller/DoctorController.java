package com.doctor.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.doctor.VO.Patient;
import com.doctor.VO.Department;
import com.doctor.VO.DoctorDepartmentResponseTemplate;
import com.doctor.VO.DoctorPatientResponseTemplate;
import com.doctor.entity.Doctor;
import com.doctor.service.DoctorService;

@RestController
@RequestMapping("/doctors")
public class DoctorController {

	@Autowired
	private DoctorService doctorService;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@PostMapping("/addDoctor")
	public Doctor addDoctor(@RequestBody Doctor doctor) {
		return doctorService.addDoctor(doctor);
	}
	
	@PostMapping("/updateDoctor")
	public Doctor updateDoctor(@RequestBody Doctor doctor) {
		return doctorService.updateDoctor(doctor);
	}
	
	@GetMapping("/fetchAllDoctor")
	public List<Doctor> fetchAllDoctor(){
		return doctorService.getAllDoctors();
		
	}
	
	@GetMapping("/fetchDoctor/{id}")
	public Doctor fetchDoctorById(@PathVariable("id") Long doctorId ) {
		return doctorService.getDoctorById(doctorId);
	}
	
	@DeleteMapping("/deleteDoctor/{id}")
	public ResponseEntity<HttpStatus> deleteDoctor(@PathVariable("id") String deptId){
		doctorService.deleteDoctor(Long.parseLong(deptId));
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	@GetMapping("/fetchDoctorPatient/{id}")
	public DoctorPatientResponseTemplate fetchDoctorPatientRecord(@PathVariable("id") String doctorId) {
		DoctorPatientResponseTemplate responseTemplateVO= new DoctorPatientResponseTemplate();
		Doctor doctor=doctorService.getDoctorById(Long.parseLong(doctorId));
		Patient patient =restTemplate.getForObject("http://localhost:8092/patients/doctorpatient/"+doctorId, Patient.class);
		responseTemplateVO.setDoctor(doctor);
		responseTemplateVO.setPatient(patient);
		return responseTemplateVO;
	}
	

	@GetMapping("/fetchDoctorDepartment/{id}")
	public DoctorDepartmentResponseTemplate fetchDoctorDepartmentRecord(@PathVariable("id") Long doctorId) {
		DoctorDepartmentResponseTemplate responseTemplateVO= new DoctorDepartmentResponseTemplate();
		Doctor doctor=doctorService.getDoctorById(doctorId);
		Department department =restTemplate.getForObject("http://localhost:8090/departments/findDepartment/"+doctor.getDepartmentId(), Department.class);
		responseTemplateVO.setDoctor(doctor);
		responseTemplateVO.setDepartment(department);
		return responseTemplateVO;
	}
	
}
