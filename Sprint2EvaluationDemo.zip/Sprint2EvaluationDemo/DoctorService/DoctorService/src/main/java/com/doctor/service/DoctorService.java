package com.doctor.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.doctor.entity.Doctor;
import com.doctor.repository.DoctorRepository;

@Service
public class DoctorService {

	@Autowired
	private DoctorRepository doctorRespository;
	
	public Doctor addDoctor(Doctor doctor) {
		return doctorRespository.save(doctor);
	}
	
	public List<Doctor> getAllDoctors(){
		return doctorRespository.findAll();
	}
	
	
	public Doctor getDoctorById(Long doctorId) {
		return doctorRespository.findByDoctorId(doctorId);
	}
	
	public Doctor updateDoctor(Doctor doctor) {
		return doctorRespository.save(doctor);
	}
	
	public void deleteDoctor(Long doctorId) {
		doctorRespository.deleteById(doctorId);
	}
}
