package com.doctor.VO;

import com.doctor.entity.Doctor;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DoctorPatientResponseTemplate {

	private Doctor doctor;
	private Patient patient;
}
