package com.patient.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.patient.VO.Doctor;
import com.patient.VO.PatientDoctorResponseTemplate;
import com.patient.entity.Patient;
import com.patient.service.PatientService;


@RestController
@RequestMapping("/patients")
public class PatientController {

	@Autowired
	private PatientService patientService;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@PostMapping("/addPatient")
	public Patient addPatient(@RequestBody Patient Patient) {
		return patientService.addPatient(Patient);
	}
	
	@PostMapping("/updatePatient")
	public Patient updatePatient(@RequestBody Patient Patient) {
		return patientService.updatePatient(Patient);
	}
	
	@GetMapping("/fetchAllPatient")
	public List<Patient> fetchAllPatient(){
		return patientService.getAllPatients();
		
	}
	
	@GetMapping("/fetchPatient/{id}")
	public Patient fetchPatientById(@PathVariable("id") Long patientId ) {
		return patientService.getPatientById(patientId);
	}
	
	@DeleteMapping("/deletePatient/{id}")
	public ResponseEntity<HttpStatus> deletePatient(@PathVariable("id") String patientId){
		patientService.deletePatient(Long.parseLong(patientId));
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	@GetMapping("/doctorpatient/{id}")
	public Patient fetchPatientByDoctorId(@PathVariable("id") String doctorId) {
		return patientService.fetchByDoctorId(Long.parseLong(doctorId));
	}
	
	@GetMapping("/patientdoctor/{id}")
	public PatientDoctorResponseTemplate fetchPatientDoctorRecord(@PathVariable("id") Long patientId) {
		PatientDoctorResponseTemplate patientDoctorResponseTemplate=new PatientDoctorResponseTemplate();
		Patient patient = patientService.getPatientById(patientId);
		Doctor doctor=restTemplate.getForObject("http://localhost:8091/doctors/fetchDoctor/"+patient.getDoctorId(), Doctor.class);
		patientDoctorResponseTemplate.setDoctor(doctor);
		patientDoctorResponseTemplate.setPatient(patient);
		return patientDoctorResponseTemplate;
	}
}
