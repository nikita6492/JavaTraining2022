package com.patient.VO;

import com.patient.entity.Patient;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PatientDoctorResponseTemplate {
	
	private Patient patient;
	private Doctor doctor;

}
