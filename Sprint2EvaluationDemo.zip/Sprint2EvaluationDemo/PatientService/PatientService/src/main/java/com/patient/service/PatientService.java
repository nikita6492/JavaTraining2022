package com.patient.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.patient.entity.Patient;
import com.patient.repository.PatientRepository;

@Service
public class PatientService {

	@Autowired
	private PatientRepository patientRepository;
	
	public Patient addPatient(Patient patient) {
		return patientRepository.save(patient);
	}
	
	public List<Patient> getAllPatients(){
		return patientRepository.findAll();
	}
	
	
	public Patient getPatientById(Long patientId) {
		return patientRepository.findByPatientId(patientId);
	}
	
	public Patient updatePatient(Patient patient) {
		return patientRepository.save(patient);
	}
	
	public void deletePatient(Long patientId) {
		patientRepository.deleteById(patientId);
	}
	
	public Patient fetchByDoctorId(Long doctorId) {
		return patientRepository.findByDoctorId(doctorId);
	}
}
