package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.BusinessException;
import com.example.demo.model.Customer;
import com.example.demo.repo.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	private CustomerRepository customerRepository;
	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return customerRepository.findAll();
	}

	@Override
	public Customer addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		if(customer.getCustName().isEmpty() || customer.getCustName().length()==0) {
			throw new BusinessException("601", "Please enter proper name!");
		}
		try {
		return customerRepository.save(customer);
		}catch (IllegalArgumentException e) {
			throw new BusinessException("602","given customer is null"+e.getMessage());
		}catch (Exception e) {
			throw new BusinessException("603","Something is wrong here!");
		}
	}

	@Override
	public Customer updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return customerRepository.save(customer);
	}

	@Override
	public void deleteCustomer(int custId) {
		// TODO Auto-generated method stub
		customerRepository.deleteById(custId);
	}

}
