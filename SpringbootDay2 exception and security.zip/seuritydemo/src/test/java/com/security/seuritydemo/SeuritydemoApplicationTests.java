package com.security.seuritydemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeuritydemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
