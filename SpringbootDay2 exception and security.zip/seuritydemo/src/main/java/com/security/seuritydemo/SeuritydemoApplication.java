package com.security.seuritydemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeuritydemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SeuritydemoApplication.class, args);
	}

}
