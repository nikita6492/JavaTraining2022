@FunctionalInterface
public interface Display {

	void print();
}
