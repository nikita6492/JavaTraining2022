package com.sprintOne.evaluation.FunctionalInterfaceDemo;

@FunctionalInterface
public interface Calculation {
	
	void calculateArea(int a);

}
