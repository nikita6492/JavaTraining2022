import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Course } from '../course';
import { NgserviceService } from '../ngservice.service';

@Component({
  selector: 'app-add-course',
  templateUrl: './add-course.component.html',
  styleUrls: ['./add-course.component.css']
})
export class AddCourseComponent implements OnInit {

  course =new Course();
  constructor(private _route:Router,private _service:NgserviceService) { }

  ngOnInit(): void {
  }

  addCourseformsubmit(){
    this._service.addCourseListFromRemote(this.course).subscribe
(
  data =>{
    console.log("Data added successfully");
    this._route.navigate(['courselist']);
  },
  error =>console.log("Error")
)
}
 
  gotolist() {
    this._route.navigate(['courselist']);
  }
  }

