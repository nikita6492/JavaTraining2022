import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Course } from './course';

@Injectable({
  providedIn: 'root'
})
export class NgserviceService {

  constructor(private _http:HttpClient) { }


  fetchCourseListFromRemote():Observable<any>{
      return this._http.get<any>('http://localhost:8090/course');
  }

  
  fetchCourseByIDFromRemote(id:number):Observable<any>{
    return this._http.get<any>('http://localhost:8090/course/'+id);
}

  addCourseListFromRemote(course:Course):Observable<any>{
    return this._http.post<any>('http://localhost:8090/course',course);
}

updateCourseListFromRemote(course:Course):Observable<any>{
  return this._http.post<any>('http://localhost:8090/course/'+course.id,course);
}

deleteCourseListFromRemote(id:number):Observable<any>{
  return this._http.delete<any>('http://localhost:8090/course/'+id);
}
}
