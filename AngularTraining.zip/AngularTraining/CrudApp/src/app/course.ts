export class Course {
    id!:number;
    title!:string;
}

