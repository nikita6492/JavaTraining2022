import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validator,Validators } from '@angular/forms';

@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.scss']
})
export class DialogComponent implements OnInit {

  freshness=['Brand New','Second Hand','Refurnish'];
  productForm!:FormGroup;
  constructor(private formBuilder:FormBuilder) { }

  ngOnInit(): void {
    this.productForm=this.formBuilder.group({
      productName: ['', Validators.required],
      category: ['', Validators.required],
      date: ['', Validators.required],
      productFreshness: ['', Validators.required],
      price: ['', Validators.required],
      comment: ['', Validators.required],
    })
  }

  public addProduct(){
  console.log(this.productForm.value)    
  }
}
