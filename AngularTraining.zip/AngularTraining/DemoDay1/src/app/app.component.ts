import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'DemoDay1';
  name = 'Ram';
  public random="";
  public num="";
 showMe:Boolean=false;
 color:string='red';
  onClick(){
    alert("this was clicked");
  }

  fruits:Fruits[] = [{name:'Apple',color:'Red',quantity:'10'},{name:'Orange',color:'Orange',quantity:'20'},{name:'Mango',color:'Yellow',quantity:'5'}]
  selectedValue:string ="Apple";
}

class Fruits{
  name!:string;
  color!:string;
  quantity!:string;
}