import { HttpClient } from '@angular/common/http';
import { Route } from '@angular/compiler/src/core';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginuserService } from '../loginuser.service';
import { User } from '../user';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {
 user =new User();
  constructor(private service:LoginuserService,private route:Router) { }

  ngOnInit(): void {
  }

  userLogin(){

    this.service.logiinUser(this.user).subscribe(
      data=>{alert("Login successfull!!");
      this.route.navigate(['login']);
    }
    ,error=>{alert("Please enter correct username and password")});

  }
}
