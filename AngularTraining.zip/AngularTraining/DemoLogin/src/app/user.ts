export class User {
    userId!:string;
    password!:string;
    name!:string;
    email!:string;
}
