import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginuserService } from '../loginuser.service';
import { User } from '../user';

@Component({
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.css']
})
export class RegisterUserComponent implements OnInit {
user=new User();
  constructor(private _service:LoginuserService,private route:Router) { }

  ngOnInit(): void {
  }
addUser(){
  this._service.addUser(this.user).subscribe(data=>{
    alert("User added successfully !!");
    this.route.navigate(["userlogin"]);
  },error=>alert("Something went wrong!!"))
}
}
