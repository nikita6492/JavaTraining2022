import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class LoginuserService {

  private baseUrl="http://localhost:8090/user/login";
  constructor(private http:HttpClient) { }

  logiinUser(user:User):Observable<Object>{
    return this.http.post(`${this.baseUrl}`,user);

  }
  addUser(user:User):Observable<Object>{
    return this.http.post("http://localhost:8090/user/addUser",user);
  }
}
