import { Subscription } from './subscription';

describe('Subscription', () => {
  it('should create an instance', () => {
    expect(new Subscription()).toBeTruthy();
  });
});
