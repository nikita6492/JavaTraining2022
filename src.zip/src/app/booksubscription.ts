export class Booksubscription {
    id!:number;
	 title!:string;
	category!:string;
	price!:number;
	author!:string;
	authorEmail!:string;
     publisher!:string;
	active!:string;
	status!:string;
	 content!:string;
     subscription!:string;

     constructor(){
         
     }
}
