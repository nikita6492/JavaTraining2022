import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewcomponent',
  templateUrl: './viewcomponent.component.html',
  styleUrls: ['./viewcomponent.component.css']
})
export class ViewcomponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
