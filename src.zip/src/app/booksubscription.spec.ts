import { Booksubscription } from './booksubscription';

describe('Booksubscription', () => {
  it('should create an instance', () => {
    expect(new Booksubscription()).toBeTruthy();
  });
});
