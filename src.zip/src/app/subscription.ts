export class Subscription {

    id!:number;
    bookId!:number;
    userId!:number;
    status!:string;

    constructor(){
        
    }
}
