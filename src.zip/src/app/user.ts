export class User {
    id:number;
    firstName:string;
    lastname:string;
    emailId:string;
    password:string;
    role:string;

    constructor( ){}
}
