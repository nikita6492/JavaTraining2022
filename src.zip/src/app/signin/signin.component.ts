import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { User } from '../user';
import { UserserviceService } from '../userservice.service';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {
 user =new User();
  constructor(private _service:UserserviceService) { }

  ngOnInit(): void {
  }

  signinUser(){
this._service.signInUserFromRemote(this.user).subscribe(
  data =>console.log("response received"),
  error =>console.log("exception occured")
)

  }
}
