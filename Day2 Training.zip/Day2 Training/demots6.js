var itemOne = {
    name: "Fridge",
    price: 50000,
    quantity: 5,
    totalPrice: function () { return itemOne.price * itemOne.quantity; }
};
var itemTwo = {
    name: "TV",
    price: 20000,
    quantity: 10,
    totalPrice: function () { return itemTwo.price * itemTwo.quantity; }
};
console.log("Item One");
console.log(itemOne.name);
console.log(itemOne.price);
console.log(itemOne.quantity);
console.log(itemOne.totalPrice());
console.log("Item Two");
console.log(itemTwo.name);
console.log(itemTwo.price);
console.log(itemTwo.quantity);
console.log(itemTwo.totalPrice());
