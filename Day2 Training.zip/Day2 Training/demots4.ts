var num:number=40
if(num>0){
    console.log("Positive number");
}else if(num<0){
    console.log("Negative number");
}else{
    console.log("Number is zero");
}