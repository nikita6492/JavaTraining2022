var message = "welcome to javascript";
console.log(message);
