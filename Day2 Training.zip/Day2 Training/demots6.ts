interface IItems{
    name:string,
    price:number,
    quantity:number,
    totalPrice: ()=>number
}

var itemOne:IItems ={
name:"Fridge",
price:50000,
quantity:5,
totalPrice:():number=>{return itemOne.price*itemOne.quantity}
}

var itemTwo:IItems ={
    name:"TV",
    price:20000,
    quantity:10,
    totalPrice:():number=>{return itemTwo.price*itemTwo.quantity}
}

console.log("Item One");
console.log(itemOne.name);
console.log(itemOne.price);
console.log(itemOne.quantity);
console.log(itemOne.totalPrice());

console.log("Item Two");
console.log(itemTwo.name);
console.log(itemTwo.price);
console.log(itemTwo.quantity);
console.log(itemTwo.totalPrice());