const names:string [] =[];
names.push("John");
names.push("Mark");
console.log(names);