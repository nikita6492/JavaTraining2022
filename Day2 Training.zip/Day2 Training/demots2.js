function division(a, b) {
    return a / b;
}
console.log(division(10, 5));
