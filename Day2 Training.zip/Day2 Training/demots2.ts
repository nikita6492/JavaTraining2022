function division(a:number, b:number){
    return a/b;
}
console.log(division(10,5));