var fruits = "O";
switch (fruits) {
    case "A": {
        console.log("Apple");
        break;
    }
    case "O": {
        console.log("Orange");
        break;
    }
    case "K": {
        console.log("Kiwi");
        break;
    }
    default: {
        console.log("Invalid choice");
        break;
    }
}
