package com.book.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.book.model.Book;

public class BookService {
	
	public List<Book> bookList = new ArrayList<Book>();

	public void addBook(Book book) {
		bookList.add(book);
	}
	
	public List<Book> getBooks(){
		return Collections.unmodifiableList(bookList);
	}
}
