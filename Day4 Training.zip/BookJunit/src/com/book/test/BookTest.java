package com.book.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.book.model.Book;
import com.book.service.BookService;

class BookTest {

	@Test
	public void assertTrueMsg() {
		BookService bookService =new BookService();
		Book javaBook = new Book("1","Java Complete Reference","ABC");
		bookService.addBook(javaBook);
		List<Book> bookList = bookService.getBooks();
		assertTrue(bookList.isEmpty(),"List of books is not empty");
	}

}
