package com.junit.demo.junitDemo;

import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.junit.demo.junitDemo.entity.Person;
import com.junit.demo.junitDemo.repo.PersonRepo;

@SpringBootTest
class PersonRepoTest {

	@Autowired
	private PersonRepo personRepo;
	
	@Test
	void isPersonExistById() {
		Person person =new Person(1,"amit");
		personRepo.save(person);
		
		Boolean accRes= personRepo.isPersonExistsById(1);
		assertTrue(accRes);
		
	}
	
	@BeforeEach
	void setUp() {
		System.out.println("Setup is started");
	}
	
	@AfterEach
	void tearDown() {
		System.out.print("Setup done");
	}
}
