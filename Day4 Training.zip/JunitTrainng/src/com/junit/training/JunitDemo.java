package com.junit.training;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.Assert;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

class JunitDemo {

	@Disabled
	@Test
	void test() {
		fail("Not yet implemented");
	}

	@BeforeAll
	static void setup() {
		System.out.println("@BeforeAll executed");
	}
	
	@BeforeEach
	void setupThis() {
		System.out.println("@BeforeEach executed");
	}
	
	@Tag("DEV")
	@Test
	void testCalcOne() {
		System.out.println("Test case one executed");
		Assert.assertEquals(4, Calculator.add(2, 2));
	}
	
	@Tag("PROD")
	@Test
	void testCalcTwo() {
		System.out.println("Test case two executed");
		Assert.assertEquals(6, Calculator.add(2, 4));
	}
	
	@AfterAll
	static void tear() {
		System.out.println("After all executed");
	}
	
	@AfterEach
	void tearThis() {
		System.out.println("After each executed");
	}
}
