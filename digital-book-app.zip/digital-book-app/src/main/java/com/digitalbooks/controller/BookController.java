package com.digitalbooks.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.digitalbooks.model.Book;
import com.digitalbooks.model.Subscription;
import com.digitalbooks.model.User;
import com.digitalbooks.service.BookService;
import com.digitalbooks.service.SubscriptionService;
import com.digitalbooks.service.UserService;

@RestController
public class BookController {

	@Autowired
	private BookService bookService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private SubscriptionService subscriptionService;
	
	@PostMapping("/api/v1/digitalbooks/author/books")
	public Book createBook(@RequestParam Long authorId, @RequestBody Book book) throws Exception {
		Optional<User> user = userService.fetchUserById(authorId);
		if(user.isPresent()) {
		book.setAuthor(user.get().getFirstName());
		}else {
			throw new Exception("Author not found!");
		}
		bookService.saveBook(book);
		return book;
	}

	@GetMapping("/api/v1/digitalbooks/search")
	public Book searchBook(@RequestParam String category, @RequestParam String title, @RequestParam Double price,
			@RequestParam String publisher, @RequestParam String author) {
		Book book = null;
		book = bookService.fetchByCategoryAndTitleAndPriceAndPublisherAndAuthor(category, title, price, publisher, author);
		return book;
	}
	
	@GetMapping("/api/v1/digitalbooks/reader/books")
	public List<Book> fetchAllSubscribedBooks(@RequestParam Long userId){
		Optional<User> user = userService.fetchUserById(userId);
		List<Subscription> subscriptionList = subscriptionService.fetchAllSubscribedBooks(user.get().getId());
		List<Book> bookList=new ArrayList<>();
		for(Subscription subscription:subscriptionList) {
			Optional<Book> book=bookService.fetchByBookId(subscription.getBookId());
			bookList.add(book.get());
		}
		
				return bookList;
	}
}
