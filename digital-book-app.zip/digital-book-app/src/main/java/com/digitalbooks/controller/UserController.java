package com.digitalbooks.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.digitalbooks.model.User;
import com.digitalbooks.service.UserService;

@RestController
public class UserController {
	
	@Autowired
	private UserService userService;
	
	
	@PostMapping("/sign-up")
	public User signUpUser(@RequestBody User user) throws Exception {
		String emailId = user.getEmail();
		/*if(emailId!=null) {
			User userObj =userService.fetchUserByEmailId(emailId);
			if(userObj!=null) {
				throw new Exception("User with email id "+emailId+" is already present!");
			}
		}*/
		User userObj =null;
		userObj=userService.saveUser(user);
		return userObj;
	}

}
