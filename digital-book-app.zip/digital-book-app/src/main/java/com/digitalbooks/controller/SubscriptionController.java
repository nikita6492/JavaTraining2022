package com.digitalbooks.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.digitalbooks.model.Book;
import com.digitalbooks.model.Subscription;
import com.digitalbooks.model.User;
import com.digitalbooks.service.BookService;
import com.digitalbooks.service.SubscriptionService;
import com.digitalbooks.service.UserService;

@RestController
public class SubscriptionController {
	
	@Autowired
	private SubscriptionService subscriptionService;
	
	@Autowired
	private BookService bookService;
	
	@Autowired
	private UserService userService;
	
	@PostMapping("/api/v1/digitalbooks/subscribe")
	public Long subscribeBook(@RequestParam Long bookId, @RequestParam String email) throws Exception {
		Subscription subscriptionObj =null;
		User user = userService.fetchUserByEmailId(email);
		String role = user.getRole();
		if(role!=null && role.equalsIgnoreCase("reader")) {
			Optional<Book> book =bookService.fetchByBookId(bookId);
			String status=book.get().getStatus();
			if(status!=null && status.equalsIgnoreCase("unblock")) {
				Subscription tempSub=subscriptionService.fetchSubscriptionByBookIdAndUserIdAndStatus(bookId,user.getId(),"subscribe");
				if(tempSub!=null) {
					throw new Exception("Book is already subscribed !");
				}else {
				Subscription subscription = new Subscription();
				subscription.setBookId(bookId);
				subscription.setUserId(user.getId());
				subscription.setStatus("subscribe");
				subscriptionObj= subscriptionService.saveSubscription(subscription);
				return subscriptionObj.getId();
				}
			}
			else {
				throw new Exception("Book is blocked so you cannot subscribe to it.");
			}
		}else {
			throw new Exception("Only Readers can subscribe book.");
		}
		
		
	}
	

	@PostMapping("/api/v1/digitalbooks/reader/{email}/books/{subscriptionId}/cancel-subscription")
	public String canceSubscription(@PathVariable("email") String email,
			@PathVariable("subscriptionId") Long subscriptionId) {
		String cancel;
		User user = userService.fetchUserByEmailId(email);
		Subscription subscription = subscriptionService.fetchBookIdByUserIdAndSubscriptionId(user.getId(),subscriptionId);
		subscription.setStatus("unsubscribe");
		Subscription subscriptionObj =subscriptionService.saveSubscription(subscription);
		if(subscriptionObj!=null) {
			cancel = "Book is successfully unsubscribed";
		}else {
			cancel = "Book is not unsubscribed";
		}
		return cancel;
	}

}
