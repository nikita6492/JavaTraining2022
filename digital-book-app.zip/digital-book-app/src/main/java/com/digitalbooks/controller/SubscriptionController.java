package com.digitalbooks.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.digitalbooks.model.Book;
import com.digitalbooks.model.Subscription;
import com.digitalbooks.model.User;
import com.digitalbooks.service.BookService;
import com.digitalbooks.service.SubscriptionService;
import com.digitalbooks.service.UserService;

@RestController
public class SubscriptionController {
	
	@Autowired
	private SubscriptionService subscriptionService;
	
	@Autowired
	private BookService bookService;
	
	@Autowired
	private UserService userService;
	
	@PostMapping("/api/v1/digitalbooks/subscribe")
	public Long subscribeBook(@RequestParam Long bookId, @RequestParam Long userId) throws Exception {
		Subscription subscriptionObj =null;
		Optional<User> user = userService.fetchUserById(userId);
		String role = user.get().getRole();
		if(role!=null && role.equalsIgnoreCase("reader")) {
			Optional<Book> book =bookService.fetchByBookId(bookId);
			String status=book.get().getStatus();
			if(status!=null && status.equalsIgnoreCase("unblock")) {
				Subscription subscription = new Subscription();
				subscription.setBookId(bookId);
				subscription.setUserId(userId);
				subscription.setStatus("subscribe");
				subscriptionObj= subscriptionService.saveSubscription(subscription);
				return subscriptionObj.getId();
			}
			else {
				throw new Exception("Book is blocked so you cannot subscribe to it.");
			}
		}else {
			throw new Exception("Only Readers can subscribe book.");
		}
		
		
	}

}
