package com.digitalbooks.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.digitalbooks.model.Subscription;

@Repository
public interface SubscriptionRepository extends JpaRepository<Subscription, Long>{

	@Query("SELECT s FROM Subscription s WHERE s.userId =?1 AND s.status=?2")
	public List<Subscription> fetchByUserIdAndStatus(Long userId, String status);
}
