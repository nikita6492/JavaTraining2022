package com.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.demo.VO.Department;
import com.demo.VO.ResponseTemplateVO;
import com.demo.entity.User;
import com.demo.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private RestTemplate restTemplate;
	
	public User saveUser(User user) {
		return this.userRepository.save(user);
	}
	
	public ResponseTemplateVO getUserWithDepartment(Long userId) {
		ResponseTemplateVO responseTemplateVO= new ResponseTemplateVO();
		User user=userRepository.findByUserId(userId);
		Department dept=restTemplate.getForObject("http://localhost:8090/departments/"+user.getDepartmentId(), Department.class);
		responseTemplateVO.setUser(user);
		responseTemplateVO.setDepartment(dept);
		return responseTemplateVO;
	}
}
