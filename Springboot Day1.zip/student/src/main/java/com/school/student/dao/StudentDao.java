package com.school.student.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.school.student.entity.Student;

public interface StudentDao extends JpaRepository<Student, Long>{

}
