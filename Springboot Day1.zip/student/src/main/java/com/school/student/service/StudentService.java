package com.school.student.service;

import java.util.List;

import com.school.student.entity.Student;

public interface StudentService {

	public List<Student> getAllStudents();
	
	public Student addStudent(Student student);
	
	public Student updateStudent(Student student);
	
	public void deleteStudent(Long id);
}
